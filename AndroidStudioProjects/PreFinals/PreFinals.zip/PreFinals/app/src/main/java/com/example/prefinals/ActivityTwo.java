package com.example.prefinals;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class ActivityTwo extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText editText2, editText3;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        Spinner spinner = findViewById(R.id.spinner3);
        Spinner spinner2 = findViewById(R.id.spinner2);

        spinner.setOnItemSelectedListener(this);
        spinner2.setOnItemSelectedListener(this);

        ArrayList<String> months = new ArrayList<>();
        months.add("1");
        months.add("2");
        months.add("3");
        months.add("4");
        months.add("5");
        months.add("6");
        months.add("7");
        months.add("8");
        months.add("9");
        months.add("10");
        months.add("11");
        months.add("12");

        /*ArrayList<String> day = new ArrayList<>();
        day.add("1");
        day.add("2");
        day.add("3");
        day.add("4");
        day.add("5");
        day.add("6");
        day.add("7");
        day.add("8");
        day.add("9");
        day.add("10");
        day.add("11");
        day.add("12");*/

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, months);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner.setAdapter(arrayAdapter);

       /* ArrayAdapter<String> arrayAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, day);
        arrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner2.setAdapter(arrayAdapter2);*/

        Button btn = findViewById(R.id.add);
        sharedPreferences = getSharedPreferences("Preferences",MODE_PRIVATE);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String first = editText2.getText().toString();
                String last = editText3.getText().toString();

                SharedPreferences.Editor editor  = sharedPreferences.edit();

                editor.putString("First", first);
                editor.putString("Last", last);
                editor.commit();
                Intent intent = new Intent(ActivityTwo.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
