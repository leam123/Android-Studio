package com.example.prefinals;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView text = findViewById(R.id.tvName);
        TextView text2 = findViewById(R.id.tvName2);
        SharedPreferences sharedPreferences = getSharedPreferences("Preferences",MODE_PRIVATE);
        String value = sharedPreferences.getString("First","");
        String value2 = sharedPreferences.getString("Last","");
        text.setText(value);
        text2.setText(value2);

        Button btn = findViewById(R.id.addNew);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ActivityTwo.class);
                startActivity(intent);
            }
        });

        Button edit1 = findViewById(R.id.e)
    }
}
